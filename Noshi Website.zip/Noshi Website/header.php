<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index1.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/cjs/popper.min.js">
      <script src="https://kit.fontawesome.com/e74610da6e.js" crossorigin="anonymous"></script>
      <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
      <script src="https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" href="path/to/aos.css" />
  <script src="path/to/aos.js"></script>
  </head>
<body>
  

 <div class="mt-3 text-center font-size">
 <p>Note: On 4000 and above purchase, delivery charges will be waived off manually | For any Query 03424935001</p></div><hr>
 <div class="container">
     <div class="row">
         <div class="col-sm-4" style="margin-top: 50px;">
            <a href="https://www.google.com/"><i class="fa-solid fa-magnifying-glass" style="color: #090c11;"></i></a>
         </div>
         <div class="col-sm-4 text-center">
             <img src="images/logo-removebg-preview.png" alt="logo" width="180px" height="180px">
         </div>
         <div class="col-sm-4 text-center" style="margin-top: 50px;">
             <a href=""><i class="fa-solid fa-right-to-bracket" style="color: #28292b; margin-right: 30px;"></i></a>
             <a href=""><i class="fa-solid fa-cart-plus" style="color: #28292b;"></i></a>
         </div>
     </div>
     <nav class="navbar sticky-top navbar-expand-lg navbar-light">
         <a class="navbar-brand" href="#">ANUSHEH</a>
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon"></span>
         </button>
       
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
           <ul class="navbar-nav">
             <li class="nav-item active">
               <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item active">
               <a class="nav-link" href="#">Skin Care</a>
             </li>
             <li class="nav-item dropdown active">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>
                 Hair Care
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="#">Action</a>
                 <a class="dropdown-item" href="#">Another action</a>
                 <a class="dropdown-item" href="#">Something else here</a>
               </div>
             </li>
             <li class="nav-item active">
               <a class="nav-link" href="#">Lip Care</a>
             </li>
             <li class="nav-item active">
               <a class="nav-link" href="#">50% Deal</a>
             </li>
           </ul>
         </div>
       </nav>
 </div>
 <hr>
 </body>