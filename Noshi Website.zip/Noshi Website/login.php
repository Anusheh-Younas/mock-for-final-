<html>
    <?php
    include 'header.php';
    ?>
    <div class="container1">
      <h2 style="text-align:center;">Login</h2>
    <form action="login.php">
    
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Name">
          </div>
        <div class="form-group">
          <label for="email">Email address</label>
          <input type="email" class="form-control" id="email" placeholder="Enter email">
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-control" id="password" placeholder="Password">
        </div>
        <div class="form-check">
          <input type="checkbox" class="form-check-input" id="check">
          <label class="form-check-label" for="check">Check me out</label>
        </div>
        <button type="submit" class="btn btn-dark" style="margin-left:200px; margin-top:30px;padding-left:13px;padding-right:13px;">Submit</button>
      </form>
      <p style="text-align:center;"><a href="">Create Account</a></p>
    </div>
      <?php
      include 'footer.php';
      ?>
</html>