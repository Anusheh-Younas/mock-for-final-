<html>
<footer>
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-1"></div>
          <div class="col-sm-5">
            <h6>Quick Links</h6>
            <p><a href="">Contact</a></p>
            <p><a href="">About Us</a></p>
            <p><a href="">Privacy Policy</a></p>
            <p><a href="">Terms of Service</a></p>
            <p><a href="">Refund Policy</a></p>
            <h6>Subscribe to our Emails</h6>
            <form>
              <div class="input-group">
                <input type="email" class="form-control" placeholder="Enter your Email" aria-label="Your Input" aria-describedby="arrowButton">
                <!-- <div class="input-group-append">
                  <button class="btn btn-primary" type="button" id="arrowButton">Arrow Button</button>
                </div> -->
              </div>
            </form>
          </div>
          <div class="col-sm-4">
            <h6>Our Mission</h6>
            <p>"Enhancing the natural beauty of your skin with the purest of ingredients. Empowering you to radiate confidence and wellness, one drop at a time."</p>
           </div>
           <div class="col-sm-2"></div>
    </footer>

</html>