<body>

    <?php
    include 'header.php';
    ?>
    <div class="container">
    <!-- <div style="border-bottom: 3px solid rgb(42, 204, 77); margin-top: 25px;"></div> -->
    <h2 style="margin-top: 20px;">Skin Care</h2>
    
    <div class="row">
      <div class="col-sm-3">
        <div class="card" style="width: 15rem;">
          <img class="card-img-top" src="images/lip.jpg" alt="Card image cap">
          <div class="card-body">
            <p class="card-text">Glowing Facewash + Glutaglow Serum + Night Cream ~ Pigmentation Kit</p>
            <h5 class="card-title">Rs.2,300.00 PKR</h5>
            <a href="#" class="btn btn-light">Add to Cart</a>
          </div>
        </div>
      </div>
      <div class="col-sm-3">
        <div class="card" style="width: 15rem;">
          <img class="card-img-top" src="images/lip2.jpg" alt="Card image cap">
          <div class="card-body">
            <p class="card-text">Glowing Facewash + Glutaglow Serum + Night Cream ~ Pigmentation Kit</p>
            <h5 class="card-title">Rs.2,300.00 PKR</h5>
            <a href="#" class="btn btn-light">Add to Cart</a>
          </div>
        </div>
      </div>
      <div class="col-sm-3">
        <div class="card" style="width: 15rem;">
          <img class="card-img-top" src="images/lip3.jpg" alt="Card image cap">
          <div class="card-body">
            <p class="card-text">Glowing Facewash + Glutaglow Serum + Night Cream ~ Pigmentation Kit</p>
            <h5 class="card-title">Rs.2,300.00 PKR</h5>
            <a href="#" class="btn btn-light">Add to Cart</a>
          </div>
        </div>
      </div>
      <div class="col-sm-3">
        <div class="card" style="width: 15rem;">
          <img class="card-img-top" src="images/lip4.jpg" alt="Card image cap">
          <div class="card-body">
            <p class="card-text">Glowing Facewash + Glutaglow Serum + Night Cream ~ Pigmentation Kit</p>
            <h5 class="card-title">Rs.2,300.00 PKR</h5>
            <a href="#" class="btn btn-light">Add to Cart</a>
          </div>
        </div>
      </div>
    </div>
 </div>
 <?php include 'footer.php'; ?>

    
  </body>