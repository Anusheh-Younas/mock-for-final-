<?php
$con=mysqli_connect("localhost","root","","blog");
if(!$con){
    die('connection Failed'. mysqli_connnect_error());
}


?>